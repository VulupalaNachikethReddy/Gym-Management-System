import { User, UserRole, UserProfile, Gym, MembershipPlan, MembershipRequest, Membership, RequestStatus } from '../types';

// MOCK DATABASE
let users: User[] = [];
let gyms: Gym[] = [];
let membershipRequests: MembershipRequest[] = [];
let memberships: Membership[] = [];

// Helper to generate IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

// Helper to simulate network delay
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));


class FirebaseService {
    private currentUser: User | null = null;

    constructor() {
        // Pre-populate with some data for demonstration
        this.seedData();
    }
    
    private seedData() {
        if (gyms.length > 0) return;
        
        const ownerId = 'owner123';
        users.push({ uid: ownerId, email: 'owner@zen.fit', role: 'owner' });

        const memberId = 'member123';
        users.push({ uid: memberId, email: 'member@zen.fit', role: 'member', profile: { name: 'Alex Doe', age: 28, gender: 'Male', location: 'San Francisco', fitnessGoal: 'Build Muscle' } });

        const gym1Id = generateId();
        gyms.push({
            id: gym1Id,
            ownerId,
            name: 'ZenFit Downtown',
            address: '123 Main St, San Francisco, CA',
            contact: '555-1234',
            description: 'A premium gym with state-of-the-art equipment and yoga classes.',
            facilities: ['Cardio Machines', 'Free Weights', 'Yoga Studio', 'Sauna'],
            membershipPlans: [
                { id: 'plan1', name: 'Monthly', price: 50, duration: 30, description: 'Basic access for 30 days.' },
                { id: 'plan2', name: 'Quarterly', price: 135, duration: 90, description: 'Save 10% with 3 months access.' },
                { id: 'plan3', name: 'Annual', price: 500, duration: 365, description: 'Best value for year-round fitness.' },
            ],
            photos: ['https://picsum.photos/seed/gym1/800/600', 'https://picsum.photos/seed/gym2/800/600']
        });

        const pastDate = new Date();
        pastDate.setDate(pastDate.getDate() - 40);
        const endDate = new Date(pastDate);
        endDate.setDate(endDate.getDate() + 30);
        
        memberships.push({
            id: generateId(),
            gymId: gym1Id,
            gymName: 'ZenFit Downtown',
            userId: memberId,
            userName: 'Alex Doe',
            plan: gyms[0].membershipPlans[0],
            startDate: pastDate.toISOString().split('T')[0],
            endDate: endDate.toISOString().split('T')[0],
            status: 'expired'
        });

        membershipRequests.push({
            id: generateId(),
            gymId: gym1Id,
            gymName: 'ZenFit Downtown',
            userId: 'newmember456',
            userName: 'Jane Smith',
            userEmail: 'jane@example.com',
            plan: gyms[0].membershipPlans[1],
            status: 'pending',
            requestDate: new Date().toISOString().split('T')[0],
        });
    }

    // --- AUTH ---
    async login(email: string, _pass: string): Promise<User> {
        await delay(500);
        const user = users.find(u => u.email === email);
        if (user) {
            this.currentUser = user;
            return user;
        }
        throw new Error('User not found');
    }

    async signup(email: string, _pass: string): Promise<User> {
        await delay(500);
        if (users.find(u => u.email === email)) {
            throw new Error('Email already in use');
        }
        const newUser: User = { uid: generateId(), email, role: null };
        users.push(newUser);
        this.currentUser = newUser;
        return newUser;
    }

    async logout(): Promise<void> {
        await delay(200);
        this.currentUser = null;
    }

    getCurrentUser(): User | null {
        return this.currentUser;
    }

    // --- USER ---
    async updateUserRole(uid: string, role: UserRole): Promise<void> {
        await delay(300);
        const userIndex = users.findIndex(u => u.uid === uid);
        if (userIndex !== -1) {
            users[userIndex].role = role;
            if (this.currentUser?.uid === uid) {
                this.currentUser.role = role;
            }
        }
    }

    async updateUserProfile(uid: string, profile: UserProfile): Promise<void> {
        await delay(300);
        const userIndex = users.findIndex(u => u.uid === uid);
        if (userIndex !== -1) {
            users[userIndex].profile = profile;
            if (this.currentUser?.uid === uid) {
                this.currentUser.profile = profile;
            }
        }
    }

    // --- GYM OWNER ---
    async addGym(gymData: Omit<Gym, 'id' | 'ownerId'>): Promise<Gym> {
        await delay(700);
        if (!this.currentUser || this.currentUser.role !== 'owner') throw new Error('Permission denied');
        const newGym: Gym = { ...gymData, id: generateId(), ownerId: this.currentUser.uid };
        gyms.push(newGym);
        return newGym;
    }

    async getOwnerGyms(ownerId: string): Promise<Gym[]> {
        await delay(500);
        return gyms.filter(g => g.ownerId === ownerId);
    }
    
    async getMembershipRequestsForOwner(ownerId: string): Promise<MembershipRequest[]> {
        await delay(500);
        const ownerGymIds = gyms.filter(g => g.ownerId === ownerId).map(g => g.id);
        return membershipRequests.filter(req => ownerGymIds.includes(req.gymId) && req.status === 'pending');
    }
    
    async updateMembershipRequestStatus(requestId: string, status: RequestStatus): Promise<void> {
        await delay(400);
        const requestIndex = membershipRequests.findIndex(req => req.id === requestId);
        if (requestIndex === -1) throw new Error('Request not found');

        membershipRequests[requestIndex].status = status;

        if (status === 'approved') {
            const request = membershipRequests[requestIndex];
            const startDate = new Date();
            const endDate = new Date();
            endDate.setDate(startDate.getDate() + request.plan.duration);

            const newMembership: Membership = {
                id: generateId(),
                gymId: request.gymId,
                gymName: request.gymName,
                userId: request.userId,
                userName: request.userName,
                plan: request.plan,
                startDate: startDate.toISOString().split('T')[0],
                endDate: endDate.toISOString().split('T')[0],
                status: 'active',
            };
            memberships.push(newMembership);
        }
    }
    
    async getMembersForOwner(ownerId: string): Promise<Membership[]> {
        await delay(600);
        const ownerGymIds = gyms.filter(g => g.ownerId === ownerId).map(g => g.id);
        const allMembers = memberships.filter(mem => ownerGymIds.includes(mem.gymId));
        // Client-side check for status update
        return allMembers.map(mem => {
            const endDate = new Date(mem.endDate);
            const today = new Date();
            today.setHours(0,0,0,0);
            if(endDate < today && mem.status === 'active') {
                return {...mem, status: 'expired'};
            }
            return mem;
        });
    }

    // --- MEMBER ---
    async getAllGyms(): Promise<Gym[]> {
        await delay(500);
        return [...gyms];
    }
    
    async requestToJoinGym(gymId: string, plan: MembershipPlan): Promise<void> {
        await delay(400);
        if (!this.currentUser || this.currentUser.role !== 'member') throw new Error('Permission denied');
        
        if (!this.currentUser.profile?.name || this.currentUser.profile.name.trim() === '') {
            throw new Error('Please complete your profile with your name before joining a gym.');
        }

        const gym = gyms.find(g => g.id === gymId);
        if (!gym) throw new Error('Gym not found');

        const newRequest: MembershipRequest = {
            id: generateId(),
            gymId,
            gymName: gym.name,
            userId: this.currentUser.uid,
            userName: this.currentUser.profile.name,
            userEmail: this.currentUser.email,
            plan,
            status: 'pending',
            requestDate: new Date().toISOString().split('T')[0],
        };
        membershipRequests.push(newRequest);
    }

    async getMyMemberships(userId: string): Promise<Membership[]> {
        await delay(500);
        const myMemberships = memberships.filter(mem => mem.userId === userId);
         // Client-side check for status update
         return myMemberships.map(mem => {
            const endDate = new Date(mem.endDate);
            const today = new Date();
            today.setHours(0,0,0,0);
            if(endDate < today && mem.status === 'active') {
                return {...mem, status: 'expired'};
            }
            return mem;
        });
    }

    async getMyMembershipRequests(userId: string): Promise<MembershipRequest[]> {
        await delay(500);
        return membershipRequests.filter(req => req.userId === userId);
    }
}

export const firebaseService = new FirebaseService();