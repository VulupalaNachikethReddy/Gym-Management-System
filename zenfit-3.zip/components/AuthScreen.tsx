
import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import Logo from './shared/Logo';
import { AuthView } from '../types';
import Spinner from './shared/Spinner';
import { ArrowLeftIcon } from './shared/icons';

interface AuthScreenProps {
  initialView: AuthView;
  onBack: () => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ initialView, onBack }) => {
  const [view, setView] = useState<AuthView>(initialView);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const { login, signup, loading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (view === 'login') {
        await login(email, password);
      } else {
        await signup(email, password);
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    }
  };
  
  const handleDemoLogin = (demoEmail: string) => {
    setEmail(demoEmail);
    setPassword('password123');
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-100 p-4">
      <div className="w-full max-w-md">
        <button onClick={onBack} className="absolute top-4 left-4 text-slate-600 hover:text-slate-900">
          <ArrowLeftIcon className="h-6 w-6" />
        </button>
        <div className="text-center mb-8">
          <Logo className="h-16 w-16 mx-auto text-primary" />
          <h1 className="text-3xl font-bold text-text-primary mt-4">Welcome to ZenFit</h1>
          <p className="text-text-secondary mt-1">
            {view === 'login' ? 'Sign in to continue' : 'Create your account'}
          </p>
        </div>

        <div className="bg-surface p-8 rounded-xl shadow-lg">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-text-secondary mb-1" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-primary focus:border-primary"
                required
              />
            </div>
            <div className="mb-6">
              <label className="block text-sm font-medium text-text-secondary mb-1" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-primary focus:border-primary"
                required
              />
            </div>
            {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-white font-semibold py-3 rounded-lg shadow-md hover:bg-primary-dark transition-colors disabled:bg-primary/50 flex items-center justify-center"
            >
              {loading ? <Spinner /> : (view === 'login' ? 'Login' : 'Sign Up')}
            </button>
          </form>
          <p className="text-center text-sm text-text-secondary mt-6">
            {view === 'login' ? "Don't have an account?" : 'Already have an account?'}
            <button
              onClick={() => setView(view === 'login' ? 'signup' : 'login')}
              className="font-semibold text-primary hover:underline ml-1"
            >
              {view === 'login' ? 'Sign Up' : 'Login'}
            </button>
          </p>
        </div>
        <div className="mt-4 text-center text-sm text-text-secondary">
          <p>Or use a demo account:</p>
          <div className="flex justify-center gap-2 mt-2">
            <button onClick={() => handleDemoLogin('owner@zen.fit')} className="text-primary hover:underline">Owner</button>
            <span>|</span>
            <button onClick={() => handleDemoLogin('member@zen.fit')} className="text-primary hover:underline">Member</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
