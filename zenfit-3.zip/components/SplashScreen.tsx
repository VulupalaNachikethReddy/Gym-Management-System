
import React from 'react';
import Logo from './shared/Logo';

const SplashScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-primary">
      <div className="animate-pulse">
        <Logo className="h-24 w-24 text-white" />
      </div>
      <h1 className="text-4xl font-bold text-white mt-6">ZenFit</h1>
      <p className="text-white/80 mt-2 text-center px-4">
        Where mindful calm meets active strength — balancing body and mind in harmony.
      </p>
    </div>
  );
};

export default SplashScreen;
