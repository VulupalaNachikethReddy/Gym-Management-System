
import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { UserRole } from '../types';
import Spinner from './shared/Spinner';
import { UserIcon, BuildingStorefrontIcon } from './shared/icons';

const RoleSelectionScreen: React.FC = () => {
  const { updateRole, user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSelectRole = async (role: UserRole) => {
    setLoading(true);
    setError(null);
    try {
      await updateRole(role);
    } catch (err: any) {
      setError(err.message || 'Failed to update role.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
      <div className="w-full max-w-lg text-center">
        <h1 className="text-3xl font-bold text-text-primary">One Last Step!</h1>
        <p className="text-text-secondary mt-2 mb-8">
          Help us personalize your experience. Are you here to manage a gym or to work out?
        </p>

        {loading ? (
          <Spinner />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <RoleCard
              icon={<BuildingStorefrontIcon className="h-12 w-12 text-primary" />}
              title="I'm a Gym Owner"
              description="Manage your gym, memberships, and connect with new clients."
              onSelect={() => handleSelectRole('owner')}
            />
            <RoleCard
              icon={<UserIcon className="h-12 w-12 text-secondary" />}
              title="I'm a Member"
              description="Explore gyms, track your fitness, and manage your memberships."
              onSelect={() => handleSelectRole('member')}
            />
          </div>
        )}

        {error && <p className="text-red-500 text-sm mt-6">{error}</p>}
      </div>
    </div>
  );
};

interface RoleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onSelect: () => void;
}

const RoleCard: React.FC<RoleCardProps> = ({ icon, title, description, onSelect }) => {
  return (
    <button
      onClick={onSelect}
      className="bg-surface p-8 rounded-xl shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all transform text-left flex flex-col items-start"
    >
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-bold text-text-primary">{title}</h3>
      <p className="text-text-secondary mt-2 flex-grow">{description}</p>
       <span className="mt-4 font-semibold text-primary">Choose Role &rarr;</span>
    </button>
  );
};

export default RoleSelectionScreen;
