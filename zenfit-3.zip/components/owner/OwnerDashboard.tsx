
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { firebaseService } from '../../services/firebaseService';
import { Gym, MembershipRequest, Membership, MembershipPlan } from '../../types';
import Spinner from '../shared/Spinner';
import { PlusIcon, BuildingStorefrontIcon, UserGroupIcon, BellAlertIcon, ArrowRightIcon, CheckIcon, XMarkIcon } from '../shared/icons';

type OwnerTab = 'gyms' | 'requests' | 'members';

const OwnerDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<OwnerTab>('gyms');

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-surface shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary">ZenFit Owner</h1>
          <div>
            <span className="text-text-secondary mr-4">Welcome, {user?.email}</span>
            <button onClick={logout} className="font-semibold text-secondary hover:underline">
              Logout
            </button>
          </div>
        </div>
        <nav className="container mx-auto px-4">
          <div className="flex border-b">
            <TabButton name="My Gyms" tab="gyms" activeTab={activeTab} setActiveTab={setActiveTab} icon={<BuildingStorefrontIcon className="h-5 w-5 mr-2" />} />
            <TabButton name="Requests" tab="requests" activeTab={activeTab} setActiveTab={setActiveTab} icon={<BellAlertIcon className="h-5 w-5 mr-2" />} />
            <TabButton name="Members" tab="members" activeTab={activeTab} setActiveTab={setActiveTab} icon={<UserGroupIcon className="h-5 w-5 mr-2" />} />
          </div>
        </nav>
      </header>

      <main className="container mx-auto p-4 md:p-6">
        {activeTab === 'gyms' && <GymsPanel />}
        {activeTab === 'requests' && <RequestsPanel />}
        {activeTab === 'members' && <MembersPanel />}
      </main>
    </div>
  );
};


const TabButton: React.FC<{ name: string; tab: OwnerTab; activeTab: OwnerTab; setActiveTab: (tab: OwnerTab) => void; icon: React.ReactNode; }> = 
({ name, tab, activeTab, setActiveTab, icon }) => (
  <button
    onClick={() => setActiveTab(tab)}
    className={`flex items-center px-4 py-3 font-semibold transition-colors ${
      activeTab === tab
        ? 'border-b-2 border-primary text-primary'
        : 'text-text-secondary hover:text-text-primary'
    }`}
  >
    {icon} {name}
  </button>
);

const GymsPanel: React.FC = () => {
    const [gyms, setGyms] = useState<Gym[]>([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const { user } = useAuth();

    const fetchGyms = useCallback(async () => {
        if(!user) return;
        setLoading(true);
        const ownerGyms = await firebaseService.getOwnerGyms(user.uid);
        setGyms(ownerGyms);
        setLoading(false);
    }, [user]);

    useEffect(() => {
        fetchGyms();
    }, [fetchGyms]);

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">My Gyms</h2>
                <button onClick={() => setShowForm(!showForm)} className="bg-primary text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-primary-dark transition-colors flex items-center">
                    <PlusIcon className="h-5 w-5 mr-2" /> {showForm ? 'Cancel' : 'Add New Gym'}
                </button>
            </div>
            {showForm && <AddGymForm onGymAdded={() => { fetchGyms(); setShowForm(false); }} />}
            {loading ? <Spinner /> : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {gyms.map(gym => (
                        <div key={gym.id} className="bg-surface rounded-lg shadow-lg overflow-hidden p-6">
                            <h3 className="text-xl font-bold text-text-primary">{gym.name}</h3>
                            <p className="text-text-secondary mt-1">{gym.address}</p>
                            <p className="text-text-secondary mt-1">Contact: {gym.contact}</p>
                            <div className="mt-4">
                                <h4 className="font-semibold mb-2">Facilities:</h4>
                                <div className="flex flex-wrap gap-2">
                                    {gym.facilities.map(f => <span key={f} className="bg-slate-200 text-slate-700 text-xs font-semibold px-2 py-1 rounded-full">{f}</span>)}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const AddGymForm: React.FC<{onGymAdded: () => void}> = ({onGymAdded}) => {
    const [name, setName] = useState('');
    const [address, setAddress] = useState('');
    const [contact, setContact] = useState('');
    const [description, setDescription] = useState('');
    const [facilities, setFacilities] = useState('');
    const [plans, setPlans] = useState<Omit<MembershipPlan, 'id'>[]>([{name: '', price: 0, duration: 30, description: ''}]);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleAddPlan = () => {
        setPlans([...plans, {name: '', price: 0, duration: 30, description: ''}]);
    }

    const handlePlanChange = <T,>(index: number, field: keyof MembershipPlan, value: T) => {
        const newPlans = [...plans];
        newPlans[index] = {...newPlans[index], [field]: value};
        setPlans(newPlans as Omit<MembershipPlan, 'id'>[]);
    }
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        const gymData = {
            name, address, contact, description,
            facilities: facilities.split(',').map(f => f.trim()),
            membershipPlans: plans.map(p => ({...p, id: Math.random().toString()})),
            photos: ['https://picsum.photos/seed/newgym/800/600']
        };
        await firebaseService.addGym(gymData);
        setIsSubmitting(false);
        onGymAdded();
    }
    
    return (
        <form onSubmit={handleSubmit} className="bg-surface p-6 rounded-lg shadow-md mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Gym Name" className="p-2 border rounded" required />
                <input value={address} onChange={e => setAddress(e.target.value)} placeholder="Address" className="p-2 border rounded" required />
                <input value={contact} onChange={e => setContact(e.target.value)} placeholder="Contact" className="p-2 border rounded" required />
                <input value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" className="p-2 border rounded md:col-span-2" required />
                <input value={facilities} onChange={e => setFacilities(e.target.value)} placeholder="Facilities (comma-separated)" className="p-2 border rounded md:col-span-2" required />
            </div>
            <h3 className="font-bold mt-4 mb-2">Membership Plans</h3>
            {plans.map((plan, index) => (
                <div key={index} className="grid grid-cols-4 gap-2 mb-2">
                    <input value={plan.name} onChange={e => handlePlanChange(index, 'name', e.target.value)} placeholder="Plan Name" className="p-2 border rounded" />
                    <input type="number" value={plan.price} onChange={e => handlePlanChange(index, 'price', +e.target.value)} placeholder="Price" className="p-2 border rounded" />
                    <input type="number" value={plan.duration} onChange={e => handlePlanChange(index, 'duration', +e.target.value)} placeholder="Duration (days)" className="p-2 border rounded" />
                    <input value={plan.description} onChange={e => handlePlanChange(index, 'description', e.target.value)} placeholder="Description" className="p-2 border rounded" />
                </div>
            ))}
            <button type="button" onClick={handleAddPlan} className="text-sm text-primary font-semibold mt-2">+ Add another plan</button>
            <button type="submit" disabled={isSubmitting} className="mt-4 bg-secondary text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-orange-600 transition-colors">
                {isSubmitting ? 'Saving...' : 'Save Gym'}
            </button>
        </form>
    );
}


const RequestsPanel: React.FC = () => {
    const [requests, setRequests] = useState<MembershipRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const { user } = useAuth();
    
    const fetchRequests = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const reqs = await firebaseService.getMembershipRequestsForOwner(user.uid);
        setRequests(reqs);
        setLoading(false);
    }, [user]);

    useEffect(() => {
        fetchRequests();
    }, [fetchRequests]);

    const handleUpdateRequest = async (requestId: string, status: 'approved' | 'declined') => {
        await firebaseService.updateMembershipRequestStatus(requestId, status);
        fetchRequests();
    }

    if (loading) return <Spinner />;
    
    return (
        <div>
            <h2 className="text-2xl font-bold mb-6">Membership Requests</h2>
            {requests.length === 0 ? <p>No pending requests.</p> : (
                <div className="space-y-4">
                    {requests.map(req => (
                        <div key={req.id} className="bg-surface rounded-lg shadow-md p-4 flex items-center justify-between">
                            <div>
                                <p className="font-bold">{req.userName} <span className="font-normal text-text-secondary">({req.userEmail})</span></p>
                                <p>Wants to join <span className="font-semibold">{req.gymName}</span> with the <span className="font-semibold">{req.plan.name}</span> plan.</p>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => handleUpdateRequest(req.id, 'approved')} className="bg-green-500 text-white p-2 rounded-full hover:bg-green-600"><CheckIcon className="h-5 w-5" /></button>
                                <button onClick={() => handleUpdateRequest(req.id, 'declined')} className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600"><XMarkIcon className="h-5 w-5" /></button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};


const MembersPanel: React.FC = () => {
    const [members, setMembers] = useState<Membership[]>([]);
    const [loading, setLoading] = useState(true);
    const { user } = useAuth();
    
    useEffect(() => {
        const fetchMembers = async () => {
            if (!user) return;
            setLoading(true);
            const mems = await firebaseService.getMembersForOwner(user.uid);
            setMembers(mems);
            setLoading(false);
        };
        fetchMembers();
    }, [user]);

    if (loading) return <Spinner />;

    return (
        <div>
            <h2 className="text-2xl font-bold mb-6">All Members</h2>
            <div className="bg-surface rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="bg-slate-100">
                        <tr>
                            <th className="p-4 font-semibold">Name</th>
                            <th className="p-4 font-semibold">Gym</th>
                            <th className="p-4 font-semibold">Plan</th>
                            <th className="p-4 font-semibold">End Date</th>
                            <th className="p-4 font-semibold">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {members.map(mem => (
                            <tr key={mem.id} className="border-b last:border-b-0">
                                <td className="p-4">{mem.userName}</td>
                                <td className="p-4">{mem.gymName}</td>
                                <td className="p-4">{mem.plan.name}</td>
                                <td className="p-4">{mem.endDate}</td>
                                <td className="p-4">
                                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${mem.status === 'active' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                                        {mem.status.charAt(0).toUpperCase() + mem.status.slice(1)}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};


export default OwnerDashboard;
