
import React, { useState } from 'react';
import { AuthView } from '../types';
import { CheckCircleIcon, ArrowRightIcon } from './shared/icons';

interface OnboardingScreenProps {
  onNavigateToAuth: (view: AuthView) => void;
}

const slides = [
  {
    title: 'Find gyms near you',
    description: 'Discover top-rated fitness centers in your area with just a few taps.',
    image: 'https://picsum.photos/seed/onboard1/1000/800',
  },
  {
    title: 'Grow your gym business',
    description: 'Reach new customers, manage memberships, and streamline your operations.',
    image: 'https://picsum.photos/seed/onboard2/1000/800',
  },
  {
    title: 'Track fitness and memberships easily',
    description: 'Stay on top of your goals and manage your gym subscriptions all in one place.',
    image: 'https://picsum.photos/seed/onboard3/1000/800',
  },
];

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onNavigateToAuth }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <div className="relative h-64 sm:h-96 md:h-[500px] w-full">
        <img src={slides[currentSlide].image} alt={slides[currentSlide].title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="absolute bottom-4 left-4 right-4 flex justify-center space-x-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2 w-8 rounded-full transition-colors ${currentSlide === index ? 'bg-primary' : 'bg-white/50'}`}
              ></button>
            ))}
        </div>
      </div>

      <div className="flex-grow flex flex-col justify-between p-6 sm:p-8 bg-surface">
        <div>
          <h2 className="text-3xl font-bold text-text-primary mb-2">{slides[currentSlide].title}</h2>
          <p className="text-text-secondary">{slides[currentSlide].description}</p>
        </div>

        <div className="mt-8">
            {currentSlide < slides.length - 1 ? (
                <button
                    onClick={nextSlide}
                    className="w-full bg-primary text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-primary-dark transition-transform transform hover:scale-105 flex items-center justify-center"
                >
                    Next <ArrowRightIcon className="ml-2 h-5 w-5" />
                </button>
            ) : (
                <div className="space-y-4">
                    <button
                        onClick={() => onNavigateToAuth('signup')}
                        className="w-full bg-primary text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-primary-dark transition-transform transform hover:scale-105"
                    >
                        Sign Up
                    </button>
                    <button
                        onClick={() => onNavigateToAuth('login')}
                        className="w-full bg-slate-200 text-text-primary font-semibold py-3 px-6 rounded-lg hover:bg-slate-300 transition-colors"
                    >
                        Login
                    </button>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default OnboardingScreen;
