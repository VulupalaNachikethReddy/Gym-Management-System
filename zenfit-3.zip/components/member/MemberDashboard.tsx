
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { firebaseService } from '../../services/firebaseService';
import { Gym, Membership, UserProfile, MembershipRequest, MembershipPlan } from '../../types';
import Spinner from '../shared/Spinner';
// Fix: Removed RocketLaunchIcon and CalendarDaysIcon as they are not exported from ../shared/icons
import { MagnifyingGlassIcon, UserCircleIcon, BookmarkIcon, MapPinIcon } from '../shared/icons';

type MemberTab = 'explore' | 'memberships' | 'profile';

const MemberDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const isProfileIncomplete = !user?.profile?.name || user.profile.name.trim() === '';
  const [activeTab, setActiveTab] = useState<MemberTab>(isProfileIncomplete ? 'profile' : 'explore');

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-surface shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary">ZenFit</h1>
          <div>
            <span className="text-text-secondary mr-4">Hello, {user?.profile?.name || user?.email}</span>
            <button onClick={logout} className="font-semibold text-secondary hover:underline">
              Logout
            </button>
          </div>
        </div>
        <nav className="container mx-auto px-4">
          <div className="flex border-b">
            <TabButton name="Explore Gyms" tab="explore" activeTab={activeTab} setActiveTab={setActiveTab} icon={<MagnifyingGlassIcon className="h-5 w-5 mr-2" />} />
            <TabButton name="My Memberships" tab="memberships" activeTab={activeTab} setActiveTab={setActiveTab} icon={<BookmarkIcon className="h-5 w-5 mr-2" />} />
            <TabButton name="Profile" tab="profile" activeTab={activeTab} setActiveTab={setActiveTab} icon={<UserCircleIcon className="h-5 w-5 mr-2" />} />
          </div>
        </nav>
      </header>

      <main className="container mx-auto p-4 md:p-6">
        {activeTab === 'explore' && <ExplorePanel />}
        {activeTab === 'memberships' && <MyMembershipsPanel />}
        {activeTab === 'profile' && <ProfilePanel />}
      </main>
    </div>
  );
};

const TabButton: React.FC<{ name: string; tab: MemberTab; activeTab: MemberTab; setActiveTab: (tab: MemberTab) => void; icon: React.ReactNode; }> = 
({ name, tab, activeTab, setActiveTab, icon }) => (
  <button
    onClick={() => setActiveTab(tab)}
    className={`flex items-center px-4 py-3 font-semibold transition-colors ${
      activeTab === tab
        ? 'border-b-2 border-primary text-primary'
        : 'text-text-secondary hover:text-text-primary'
    }`}
  >
    {icon} {name}
  </button>
);


const ExplorePanel: React.FC = () => {
    const [gyms, setGyms] = useState<Gym[]>([]);
    const [filteredGyms, setFilteredGyms] = useState<Gym[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedGym, setSelectedGym] = useState<Gym | null>(null);

    useEffect(() => {
        const fetchGyms = async () => {
            setLoading(true);
            const allGyms = await firebaseService.getAllGyms();
            setGyms(allGyms);
            setFilteredGyms(allGyms);
            setLoading(false);
        };
        fetchGyms();
    }, []);

    useEffect(() => {
        const lowercasedFilter = searchTerm.toLowerCase();
        const filteredData = gyms.filter(item => {
            return Object.values(item).some(value =>
                String(value).toLowerCase().includes(lowercasedFilter)
            );
        });
        setFilteredGyms(filteredData);
    }, [searchTerm, gyms]);

    if (loading) return <Spinner />;

    return (
        <div>
            <div className="mb-6">
                <input
                    type="text"
                    placeholder="Search gyms by name, location, or facility..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-primary focus:border-primary"
                />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredGyms.map(gym => (
                    <div key={gym.id} className="bg-surface rounded-lg shadow-lg overflow-hidden transition-transform transform hover:-translate-y-1 cursor-pointer" onClick={() => setSelectedGym(gym)}>
                        <img src={gym.photos[0]} alt={gym.name} className="h-48 w-full object-cover" />
                        <div className="p-4">
                            <h3 className="text-xl font-bold">{gym.name}</h3>
                            <p className="text-text-secondary flex items-center mt-1"><MapPinIcon className="h-4 w-4 mr-1" />{gym.address}</p>
                        </div>
                    </div>
                ))}
            </div>
            {selectedGym && <GymDetailsModal gym={selectedGym} onClose={() => setSelectedGym(null)} />}
        </div>
    );
}

const GymDetailsModal: React.FC<{ gym: Gym; onClose: () => void }> = ({ gym, onClose }) => {
    const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

    const handleJoin = async (plan: MembershipPlan) => {
        try {
            await firebaseService.requestToJoinGym(gym.id, plan);
            setMessage({ text: `Request to join with ${plan.name} plan sent!`, type: 'success' });
        } catch (e: any) {
             const errorMessage = e.message.includes('complete your profile')
                ? `${e.message} You can update it in the 'Profile' tab.`
                : e.message;
            setMessage({ text: `Error: ${errorMessage}`, type: 'error' });
        }
    }
    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-surface rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <div className="relative">
                     <img src={gym.photos[0]} alt={gym.name} className="h-64 w-full object-cover rounded-t-lg" />
                     <button onClick={onClose} className="absolute top-4 right-4 bg-white/80 rounded-full p-2 text-text-primary hover:bg-white">&times;</button>
                </div>
                <div className="p-6">
                    <h2 className="text-3xl font-bold">{gym.name}</h2>
                    <p className="text-text-secondary mt-1">{gym.address}</p>
                    <p className="mt-4">{gym.description}</p>
                    <h3 className="font-bold mt-6 mb-2 text-xl">Facilities</h3>
                    <div className="flex flex-wrap gap-2">
                        {gym.facilities.map(f => <span key={f} className="bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-1 rounded-full">{f}</span>)}
                    </div>
                    <h3 className="font-bold mt-6 mb-2 text-xl">Membership Plans</h3>
                    <div className="space-y-4">
                        {gym.membershipPlans.map(plan => (
                            <div key={plan.id} className="border p-4 rounded-lg flex justify-between items-center">
                                <div>
                                    <h4 className="font-bold">{plan.name} - ${plan.price}/{plan.duration} days</h4>
                                    <p className="text-sm text-text-secondary">{plan.description}</p>
                                </div>
                                <button onClick={() => handleJoin(plan)} className="bg-secondary text-white font-semibold py-2 px-4 rounded-lg hover:bg-orange-600">Join</button>
                            </div>
                        ))}
                    </div>
                    {message && <p className={`mt-4 text-center font-semibold ${message.type === 'success' ? 'text-green-600' : 'text-red-500'}`}>{message.text}</p>}
                </div>
            </div>
        </div>
    );
};


const MyMembershipsPanel: React.FC = () => {
    const [memberships, setMemberships] = useState<Membership[]>([]);
    const [requests, setRequests] = useState<MembershipRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const { user } = useAuth();

    const fetchData = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const [mems, reqs] = await Promise.all([
            firebaseService.getMyMemberships(user.uid),
            firebaseService.getMyMembershipRequests(user.uid)
        ]);
        setMemberships(mems);
        setRequests(reqs);
        setLoading(false);
    }, [user]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    if (loading) return <Spinner />;

    return (
        <div>
            <h2 className="text-2xl font-bold mb-6">Active & Past Memberships</h2>
            {memberships.length === 0 ? <p>You have no active or past memberships.</p> :
             <div className="space-y-4">
                {memberships.map(mem => (
                     <div key={mem.id} className={`bg-surface p-4 rounded-lg shadow-md border-l-4 ${mem.status === 'active' ? 'border-green-500' : 'border-red-500'}`}>
                        <div className="flex justify-between items-start">
                             <div>
                                <h3 className="font-bold text-lg">{mem.gymName}</h3>
                                <p className="text-text-secondary">{mem.plan.name} Plan</p>
                             </div>
                             <span className={`px-2 py-1 text-xs font-semibold rounded-full ${mem.status === 'active' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                                {mem.status.charAt(0).toUpperCase() + mem.status.slice(1)}
                            </span>
                        </div>
                        <p className="text-sm mt-2">Expires on: {mem.endDate}</p>
                     </div>
                ))}
            </div>
            }
             <h2 className="text-2xl font-bold mt-8 mb-6">Pending & Recent Requests</h2>
             {requests.length === 0 ? <p>You have no pending membership requests.</p> :
             <div className="space-y-4">
                {requests.map(req => (
                     <div key={req.id} className={`bg-surface p-4 rounded-lg shadow-md border-l-4 ${
                         req.status === 'pending' ? 'border-yellow-500' : req.status === 'approved' ? 'border-green-500' : 'border-red-500'
                     }`}>
                        <div className="flex justify-between items-start">
                             <div>
                                <h3 className="font-bold text-lg">{req.gymName}</h3>
                                <p className="text-text-secondary">{req.plan.name} Plan</p>
                             </div>
                             <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                 req.status === 'pending' ? 'bg-yellow-200 text-yellow-800' : req.status === 'approved' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'
                             }`}>
                                {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                            </span>
                        </div>
                        <p className="text-sm mt-2">Requested on: {req.requestDate}</p>
                     </div>
                ))}
            </div>
            }
        </div>
    );
};

const ProfilePanel: React.FC = () => {
    const { user, updateProfile, loading } = useAuth();
    const [profile, setProfile] = useState<UserProfile>(user?.profile || { name: '', age: 0, gender: '', location: '', fitnessGoal: '' });
    const [message, setMessage] = useState<string | null>(null);

    const isProfileIncomplete = !user?.profile?.name || user.profile.name.trim() === '';
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setMessage(null);
        setProfile({...profile, [e.target.name]: e.target.value});
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await updateProfile(profile);
            setMessage('Profile saved successfully!');
        } catch (err) {
            setMessage('Failed to save profile.');
        }
    }
    
    return (
        <div className="max-w-xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">My Profile</h2>
            {isProfileIncomplete && (
                 <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6" role="alert">
                    <p className="font-bold">Welcome to ZenFit!</p>
                    <p>Please complete your profile with at least your name to start joining gyms.</p>
                </div>
            )}
            {message && (
                <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p>{message}</p>
                </div>
            )}
            <form onSubmit={handleSubmit} className="bg-surface p-6 rounded-lg shadow-md">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-text-secondary mb-1">Name</label>
                        <input name="name" value={profile.name} onChange={handleChange} className="w-full p-2 border rounded" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-secondary mb-1">Age</label>
                        <input type="number" name="age" value={profile.age} onChange={handleChange} className="w-full p-2 border rounded" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-secondary mb-1">Gender</label>
                        <select name="gender" value={profile.gender} onChange={handleChange} className="w-full p-2 border rounded bg-white">
                            <option>Select...</option>
                            <option>Male</option>
                            <option>Female</option>
                            <option>Other</option>
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-text-secondary mb-1">Location</label>
                        <input name="location" value={profile.location} onChange={handleChange} className="w-full p-2 border rounded" />
                    </div>
                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-text-secondary mb-1">Primary Fitness Goal</label>
                        <input name="fitnessGoal" value={profile.fitnessGoal} onChange={handleChange} className="w-full p-2 border rounded" />
                    </div>
                </div>
                 <button type="submit" disabled={loading} className="mt-6 bg-primary text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-primary-dark transition-colors">
                    {loading ? 'Saving...' : 'Save Profile'}
                </button>
            </form>
        </div>
    );
};

export default MemberDashboard;
