
import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      stroke="currentColor"
    >
      <path
        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"
        fill="currentColor"
        strokeWidth="0"
      />
      <path
        d="M12 4c-2.58 0-4.87 1.29-6.36 3.3A8.025 8.025 0 0112 4zm0 16c2.58 0 4.87-1.29 6.36-3.3A8.025 8.025 0 0112 20zM4 12c0 2.58 1.29 4.87 3.3 6.36A8.025 8.025 0 014 12zm16 0c0-2.58-1.29-4.87-3.3-6.36A8.025 8.025 0 0120 12z"
        fill="currentColor"
        opacity="0.3"
        strokeWidth="0"
      />
      <path
        d="M12 6a6 6 0 100 12 6 6 0 000-12zm0 10a4 4 0 110-8 4 4 0 010 8z"
        fill="currentColor"
        strokeWidth="0"
      />
    </svg>
  );
};

export default Logo;
