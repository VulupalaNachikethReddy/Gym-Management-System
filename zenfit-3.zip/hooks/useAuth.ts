
import React, { useState, useEffect, useContext, createContext, useCallback } from 'react';
import { firebaseService } from '../services/firebaseService';
import { User, UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  role: UserRole | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<User>;
  signup: (email: string, pass: string) => Promise<User>;
  logout: () => Promise<void>;
  updateRole: (role: UserRole) => Promise<void>;
  updateProfile: (profile: UserProfile) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const currentUser = firebaseService.getCurrentUser();
    setUser(currentUser);
    setLoading(false);
  }, []);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const loggedInUser = await firebaseService.login(email, pass);
      setUser(loggedInUser);
      return loggedInUser;
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const newUser = await firebaseService.signup(email, pass);
      setUser(newUser);
      return newUser;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await firebaseService.logout();
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const updateRole = useCallback(async (role: UserRole) => {
    if (!user) throw new Error("No user logged in");
    await firebaseService.updateUserRole(user.uid, role);
    setUser(prev => prev ? { ...prev, role } : null);
  }, [user]);

  const updateProfile = useCallback(async (profile: UserProfile) => {
    if (!user) throw new Error("No user logged in");
    await firebaseService.updateUserProfile(user.uid, profile);
    setUser(prev => prev ? { ...prev, profile } : null);
  }, [user]);

  const value = {
    user,
    role: user?.role || null,
    loading,
    login,
    signup,
    logout,
    updateRole,
    updateProfile,
  };

  // Fix: Replaced JSX with React.createElement to support .ts file extension
  // and fixed related compilation errors on line 84.
  return React.createElement(AuthContext.Provider, { value: value }, children);
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Fix: Removed commented-out and broken experimental code that was causing compilation errors.
